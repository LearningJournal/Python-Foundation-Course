from calculator import add, div

x = add(100, 25)
print('Addition:', x)

y = div(100, 25)
print('Division:', y)