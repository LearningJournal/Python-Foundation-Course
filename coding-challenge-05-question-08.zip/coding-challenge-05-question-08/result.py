from volume1 import volume_1
from volume2 import volume_2

if __name__ == "__main__":
    obj_1 = volume_1(3, 4, 5)
    obj_2 = volume_2(6, 7)

    obj_1.cuboid()
    obj_2.sphere()