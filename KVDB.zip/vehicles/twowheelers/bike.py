class Bar:
    pass
